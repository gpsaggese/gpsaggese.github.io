# Chess Milestone 2 preparation

Prepared November 13, 2026. The experiment is `chess_m2_v1`.

On November 18, the user approved **$3 for the first validation stage only**,
with results to be reported before releasing later phases. That stage finished
all 300 continuations (1,482 paid model calls) in 93.8 minutes for $1.5271121 of
usage-rated API spending, with zero infrastructure errors. Its authorization,
pinned execution manifest, ledger, results, audit and report are under
`experiments/m2_v1/validation_stage_20261118/`. Primary profiles and stability
repeats remain blocked; full Milestone 2 is incomplete. The original preparation manifest is retained as the
historical proposal; the stage authorization records the subsequent approval.

## Inputs and provenance

The source is PR [917](https://github.com/gpsaggese/gpsaggese.github.io/pull/917),
commit `8799acfc484febd0c9156ccca0bfa00fb0724aeb`. All 50 project files were
verified against their Git blob IDs and are preserved in `vendor/pr917/`.
`source_provenance.json` records their SHA-256 values.

The original run archive was copied to `inputs/archive/m1_runs.tar.gz`, checked
against SHA-256 `d63ef2d94a695280cffa1896bbe201e0f2d3f79def9b90751801c6f09e3a7172`,
then freshly extracted to `inputs/m1_original/`. This is separate from the
temporary review store, which had accumulated additional replay branches.
Inputs are excluded from git and kept locally. The original archive remains
available in the [shared Drive folder](https://drive.google.com/drive/folders/1cI_sX1Okc0YeLyVycOty-NRNa0xeiiRm).

Historical checkpoints identify a dirty source checkout. That limitation remains
visible in the inventory; pinning the PR source does not retroactively prove
the exact original executable source. Earlier review reproduced 62/62 replay
checks with this PR implementation. New paid execution must pin its own code.

## Inventory

| Quantity | Count |
| --- | ---: |
| Thinking-on pilot runs | 10 |
| Starting positions | 5 |
| Successful / failed runs | 3 / 7 |
| Distinct positions represented by failures | 4 |
| Pilot checkpoints, including initial and terminal | 72 |
| Pilot decision boundaries | 62 |
| Decision boundaries in failed runs | 48 |
| Terminal failed-run endpoints, scored without API calls | 7 |

`experiments/m2_v1/checkpoint_inventory.csv` includes all 72 pilot checkpoints;
`decision_inventory.csv` links each original reply to its before/after pair;
`run_inventory.csv` lists the ten runs. Oracle fields are diagnostic metadata,
never permitted predictor inputs. The original store includes 2,904 snapshots
across all 634 branches, including M1 replay, screening, and A/A branches; those
descendants are historical evidence, not additional independent pilot runs.

Integrity checks verified 4,040 content-addressed blobs, all 634 tape hash
chains, database integrity, tablebase hashes, source hashes, and unchanged
original database and ledger. See `integrity.json`.

## Proposed experiment and budget

| Phase | Design | Continuations | Expected USD | Proposed ceiling USD |
| --- | --- | ---: | ---: | ---: |
| Estimator validation | 3 decisions × 2 arms × 50 | 300 | 1.45 | 3 |
| Primary profiles | All 48 failed-run boundaries × 30 | 1,440 | 6.98 | 16 |
| Stability repeats | Two complete profiles, 17 boundaries × 30 | 510 | 2.47 | 6 |
| Total | | 2,250 | 10.90 | 25 |

This is a historical-usage forecast, not a quote or guaranteed bill. The
planning range is $8.18–$16.35 (0.75–1.5 times the historical-mean forecast),
not a statistical confidence interval. The estimate uses 500 original fresh
forks and 2,489 actual model calls, repriced at current standard rates. Their
mean is $0.004845 per fork and their empirical 95th percentile is $0.008925.
The source selected still-winnable checkpoints; M2 also includes flat and lost
states, so its cost distribution can differ. A forced terminal reply may end
a branch without a new paid call; the mean-based forecast does not discount it.

Pricing checked November 13, 2026 against
[Anthropic's official pricing](https://platform.claude.com/docs/en/about-claude/pricing):
Haiku 5.5 standard input/output costs $0.10/$0.50 per million tokens up to
100K input tokens; five-minute cache writes are $0.125 and cache reads $0.01.
Above 100K input tokens the base input/output rates become $0.50/$2.50.
No batch discount is assumed. Account-specific charges and taxes are excluded.
`budget.json` records assumptions and stage ceilings.

Recommended authorization sequence: first approve only the $3 validation
stage, review execution quality and spending, then release the remaining
phases within the proposed $25 total. No amount is approved by this document.

The vendor's pre-call ledger check is not a strict concurrent spending cap.
`m2_runtime/budget.py` now replaces it in the stage executor with transactional
SQLite reservations. Each call reserves $0.665: a maximum 1M-token input entirely
at the expensive five-minute cache-write rate, plus the full 16K-token output
allowance at long-context pricing. Requests use standard global inference.
Actual usage, including thinking and cache tokens, reconciles the reservation;
unknown transport failures retain its full liability and stop the stage.
Outstanding reservations survive a crash. Hidden model retries are disabled.
These controls passed seven budget tests and three transport integration tests,
alongside all eleven original chess tests. The approved ceiling is $3, not $25.

## Estimand and decisions selected for validation

Repair gain is `P(win | re-decide) - P(win | keep original reply)`; the original
proposal's Delta has the opposite sign. The intervention unit is the complete
assistant reply, including explanation and command, not the move alone.
Both arms restore the same before-checkpoint, same remaining limits, and same
model policy. A forced reply consumes its original step.

| Case | Original decision | Reason selected |
| --- | --- | --- |
| A | `krk-m3-1`, trial 0, step 2 | Nonterminal loss of the forced win |
| B | `krk-m4-1`, trial 0, step 1 | Position remains winnable |
| C | `krk-m8-1`, trial 0, step 3 | Terminal rook loss |

Selection is deterministic from the original trajectories and tablebase labels,
without using M1 screening win rates or new M2 outcomes. These are diagnostic
cases and not a representative causal-effect sample. `force_once_preflight.json`
records offline matching of environment, API-visible conversation, and step /
termination counters for all three cases. Actual spending metadata intentionally
differs for a forced reply.

Primary sampling uses fresh independent outcomes, 30 per nonterminal boundary,
without reusing M1 outcomes or direct-arm validation samples. Terminal values
come from actual sealed-board outcomes, without paid calls. Repeat the full
trial-0 profiles of `krk-m3-1` and `krk-m6-1` independently for stability.

Compare direct gains with `V(before) - V(after)` only after primary profiles
provide independent checkpoint estimates. Use the frozen equivalence criterion
in the manifest; unresolved comparisons stay unresolved. With 30/50 samples,
the criterion can be underpowered. Do not enlarge the tolerance after seeing
results or present unvalidated checkpoint-value changes as causal blame.

Use Wilson intervals for win rates and Newcombe intervals for differences.
Apply Holm correction for primary decision-level tests. Retain shared-checkpoint
dependence when summarizing whole profiles. No optional stopping or automatic
extra sampling. Additional confirmatory experiments require another manifest.
Sparse/diffuse conclusions remain exploratory when uncertainty is large.

## Reproduce the preparation without paid runs

Use Python 3.12. `requirements-preparation.lock` records the exact environment
used on this Mac; package availability may differ on another platform.

```bash
uv venv --python 3.12 .venv
uv pip install --python .venv/bin/python -r requirements-preparation.lock
.venv/bin/python scripts/prepare_m2.py
.venv/bin/python scripts/verify_force_once_v2.py
```

The inventory script imports only board/store modules and opens the original
database read-only. Force-once verification copies the store to a temporary
directory, makes only the scratch database writable, blocks socket connections and live model queries, uses a local
LiteLLM cost map, and avoids the user's model configuration directory. It never
launches the job list. The separately authorized paid stage command is
`scripts/run_validation_stage.py`, which refuses to initialize a second run
over an existing execution manifest.

## Milestone 4 compatibility

All trials and descendants of one starting position must stay together in
future train/evaluation splits. Keep pre-decision features in a separate table
from oracle diagnostics, outcomes, and gain labels. These seven failures cover
only four starting positions; expand the task population before making claims
about generalization. No retail jobs or Milestone 4 training are part of this
preparation.
